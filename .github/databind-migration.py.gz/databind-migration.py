from pathlib import Path
import re, subprocess
R=Path.cwd()
def orig(p): return subprocess.check_output(['git','show','HEAD:'+str(p)],cwd=R,text=True)
def put(p,s): (R/p).write_text(s)
def rep(s,a,b,n=1):
    assert s.count(a)==n, (s.count(a),n,a[:130])
    return s.replace(a,b)
def fn(s,name,edit):
    pattern=r'^[\w *]+\b'+re.escape(name)+r'\([^;{]*\)\s*\{'
    matches=list(re.finditer(pattern,s,re.M)); assert len(matches)==1,(name,len(matches))
    m=matches[0];d=1
    for t in re.finditer(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*.*?\*/|//[^\n]*|[{}]',s[m.end():],re.S):
        if t[0]=='{':d+=1
        elif t[0]=='}':d-=1
        if d==0:
            e=m.end()+t.end();return s[:m.start()]+edit(s[m.start():e])+s[e:]
    raise ValueError(name)
def names(s):
    s=s.replace('turbo_json_doc_t','json_value_t').replace('turbo_json_path_error','json_path_get_error')
    for a,b in [('turbo_json_','json_'),('TURBO_JSON_','JSON_'),('turbo_csv_','csv_'),
        ('turbo_dsv_filter_','dsv_filter_'),('turbo_datetime_','datetime_'),('turbo_parse_datetime','datetime_parse'),
        ('turbo_query_status_t','qvm_status_t'),('TURBO_QUERY_DEFAULT_','QVM_DEFAULT_'),('TURBO_QUERY_','QVM_STATUS_'),
        ('turbo_xml_sax_','salts_xml_sax_'),('turbo_yaml_sax_','cyaml_sax_')]:s=s.replace(a,b)
    s=s.replace('"turbo_parser_json.h"','<json_parser.h>').replace('"turbo_parser_common.h"','<query_vm.h>').replace('"turbo_parser_datetime.h"','<datetime_parser.h>')
    return s
for p in subprocess.check_output(['git','ls-files','tbe'],cwd=R,text=True).splitlines():
    if '/parser_compat/' in p or Path(p).suffix not in {'.c','.h','.cpp','.mustache','.md'}:continue
    s=orig(p);t=names(s)
    if s!=t:put(p,t)
p='tbe/data_bind/data_bind.h';s=names(orig(p))
s=s.replace('#include <query_vm.h>','#include <query_vm.h>\n#include <stdbool.h>\n#include <time.h>\n#include <vstr.h>')
a=s.index('/** Format-neutral query VM budgets');b=s.index('#define DATA_BIND_STREAM_LIMITS_INIT',a)
s=s[:a]+'''/** Format-neutral query VM budgets copied into one stream handle. */
typedef struct DataBindQueryLimits {
  size_t size;
  uint32_t max_instructions;
  uint32_t max_operands;
  uint32_t max_regexes;
  uint32_t max_steps;
} DataBindQueryLimits;

#define DATA_BIND_QUERY_DIAGNOSTIC_MESSAGE_CAPACITY 160u
/** Caller-owned native query diagnostic, independent of parser lifetime. */
typedef struct DataBindQueryDiagnostic {
  size_t size;
  qvm_status_t status;
  uint32_t instruction;
  uint8_t opcode;
  uint8_t reserved[3];
  uint32_t operand;
  char message[DATA_BIND_QUERY_DIAGNOSTIC_MESSAGE_CAPACITY];
} DataBindQueryDiagnostic;

#define DATA_BIND_QUERY_LIMITS_INIT \\
  {sizeof(DataBindQueryLimits), QVM_DEFAULT_MAX_INSTRUCTIONS, \\
   QVM_DEFAULT_MAX_OPERANDS, QVM_DEFAULT_MAX_REGEXES, QVM_DEFAULT_MAX_STEPS}
#define DATA_BIND_QUERY_DIAGNOSTIC_INIT \\
  {sizeof(DataBindQueryDiagnostic), QVM_STATUS_OK, QVM_NO_INSTRUCTION, \\
   QVM_NO_OPCODE, {0, 0, 0}, QVM_NO_OPERAND, {0}}

'''+s[b:]
s=s.replace('DataBind-owned name for the legacy parser-compatible datetime layout.','DataBind datetime uses the native Salts parser layout.')
put(p,s)
p='tbe/data_bind/data_bind.c';s=names(orig(p))
s=rep(s,'#include "turbo_parser.h"','''#include <json_parser.h>
#include <csv_parser.h>
#include <dsv_filter.h>
#include <cyaml.h>
#include <cyaml_json_adapter.h>
#include <xml_parser/xml_parser.h>
#include <xml_parser/xml_sax.h>''')
a=s.index('typedef enum data_bind_wire_type')
s=s[:a]+'''/* DataBind owns diagnostics after the native query/program has been released. */
static void db_query_diagnostic_copy(DataBindQueryDiagnostic *out,
                                     const qvm_diagnostic_t *native) {
  size_t size;
  if (!out || out->size < sizeof(*out) || !native) return;
  size = out->size;
  *out = (DataBindQueryDiagnostic)DATA_BIND_QUERY_DIAGNOSTIC_INIT;
  out->size = size;
  out->status = native->status;
  out->instruction = native->instruction;
  out->opcode = native->opcode;
  out->operand = native->operand;
  snprintf(out->message, sizeof(out->message), "%s", native->message ? native->message : "");
}

static qvm_limits_t db_query_native_limits(const DataBindQueryLimits *limits) {
  if (!limits) return qvm_default_limits();
  return (qvm_limits_t){limits->max_instructions, limits->max_operands,
                        limits->max_regexes, limits->max_steps};
}

'''+s[a:]
s,n=re.subn(r'turbo_parse_json\(\(const uint8_t \*\)(\w+), (\w+), &(\w+)\) != 0',lambda m:f'({m[3]} = json_parse({m[1]}, {m[2]})) == NULL',s);assert n==7,n
s,n=re.subn(r'turbo_parse_csv_opts\(\(const uint8_t \*\)(\w+), (\w+), &(\w+),\s*&([\w>\-]+)\) != 0',lambda m:f'({m[4]} = csv_parse_opts({m[1]}, {m[2]}, &{m[3]})) == NULL',s);assert n==6,n
# Parenthesized expressions preserve single-statement call sites and clear released owners.
for a,b in [('turbo_free_json','json_free'),('turbo_free_csv','csv_free')]:
    s=re.sub(r'\b'+a+r'\(&([\w>\-]+)\)',lambda m:f'({b}({m[1]}), {m[1]} = NULL)',s)
s=rep(s,'cyaml_sax_parser_create(&DATA_BIND_YAML_SAX_VALIDATE_HANDLER, parser);','cyaml_sax_parser_create(&DATA_BIND_YAML_SAX_VALIDATE_HANDLER, parser, NULL);')
s=rep(s,'message = cyaml_sax_parser_error(parser->yaml_sax);','const cyaml_error_t *native_error = cyaml_sax_parser_error(parser->yaml_sax);\n      message = native_error ? native_error->msg : NULL;')
s,n=re.subn(r'(salts_xml_sax_parser_create\([\s\S]*?\n\s*parser)\);',r'\1, parser->limits.max_input_bytes);',s);assert n==1,n
s=fn(s,'data_bind_stream_set_limits',lambda f:rep(f,'  parser->limits = *limits;','''  if (parser->xml_sax != NULL &&
      salts_xml_sax_parser_set_buffer_limit(parser->xml_sax, limits->max_input_bytes) != 0) {
    return db_error_set(parser->error, DATA_BIND_ERR_INVALID_ARG,
                        "data_bind_stream_set_limits", -1, -1,
                        "XML parser limits cannot change after parsing starts");
  }
  parser->limits = *limits;'''))
# XML DOM is an owned value; native node and text handles borrow its lifetime.
s=s.replace('turbo_xml_doc_t *doc','const salts_xml_document *doc').replace('const salts_xml_document *doc = NULL;','salts_xml_document doc = {0};')
s=s.replace('turbo_xml_list_t nodes;','salts_xml_node_list nodes = {0};').replace('turbo_xml_list_free(&nodes)','salts_xml_node_list_destroy(&nodes)').replace('nodes.len','nodes.size')
s=s.replace('turbo_free_xml(&doc)','salts_xml_document_destroy(&doc)')
s=s.replace('turbo_parse_xml((const uint8_t *)xml, len, &doc) != 0 || doc == NULL','salts_xml_parse(&doc, xml, len, NULL, NULL) != SALTS_XML_OK')
s,n=re.subn(r'turbo_parse_xml\(\(const uint8_t \*\)parser->xml_capture, tstr_len\(parser->xml_capture\), &doc\) !=\s*0\s*\|\|\s*doc == NULL','salts_xml_parse(&doc, parser->xml_capture, tstr_len(parser->xml_capture),\n                      NULL, NULL) != SALTS_XML_OK',s);assert n==1,n
a=s.index('static int xml_path_exists(');b=s.index('static int xml_field_path(',a)
s=s[:a]+'''static int xml_path_exists(const salts_xml_document *doc, const char *path) {
  salts_xml_node_list nodes = {0};
  int found;
  if (!doc || !path) return 0;
  if (salts_xml_document_xpath_query(doc, path, &nodes, NULL, NULL) != QVM_STATUS_OK) {
    salts_xml_node_list_destroy(&nodes);
    return 0;
  }
  found = salts_xml_node_list_size(&nodes) != 0;
  salts_xml_node_list_destroy(&nodes);
  return found;
}

static const char *xml_path_text(const salts_xml_document *doc, const char *path) {
  salts_xml_node_list nodes = {0};
  const char *text = NULL;
  if (!doc || !path) return NULL;
  if (salts_xml_document_xpath_query(doc, path, &nodes, NULL, NULL) == QVM_STATUS_OK &&
      salts_xml_node_list_size(&nodes) != 0) {
    salts_xml_node node = salts_xml_node_list_at(&nodes, 0);
    text = salts_xml_node_text_view(node).data;
  }
  /* The selected list owns no node/text; text remains borrowed from doc. */
  salts_xml_node_list_destroy(&nodes);
  return text;
}

'''+s[b:]
for arg in ['path','children']:
 s=rep(s,f'  turbo_xml_xpath_query(doc, {arg}, &nodes);',f'''  if (salts_xml_document_xpath_query(doc, {arg}, &nodes, NULL, NULL) != QVM_STATUS_OK) {{
    salts_xml_node_list_destroy(&nodes);
    return NULL;
  }}''')
s=rep(s,'turbo_xml_for(node, &nodes) {','''for (size_t i = 0; i < salts_xml_node_list_size(&nodes); ++i) {
    salts_xml_node node = salts_xml_node_list_at(&nodes, i);''')
s=s.replace('turbo_xml_xpath_node_name((const turbo_xml_xpath_node_t *)node)','salts_xml_node_display_name(node).data').replace('turbo_xml_xpath_node_text((const turbo_xml_xpath_node_t *)node)','salts_xml_node_text_view(node).data')
for name in ['data_bind_stream_xml_bind_capture','data_bind_parse_xml','data_bind_parse_xml_path_all_with_query','data_bind_validate_xml_path']:
 s=fn(s,name,lambda f:f.replace(', doc,',', &doc,'))
s=re.sub(r'for \(int i = 0; i < nodes.size; i\+\+\)', 'for (size_t i = 0; i < nodes.size; i++)',s)
s=s.replace('"%s[%d]", path, i + 1','"%s[%zu]", path, i + 1').replace('"(%s)[%d]", xmlpath, i + 1','"(%s)[%zu]", xmlpath, i + 1')
# YAML uses a by-value owned selection result and borrowed nodes.
s=s.replace('turbo_yaml_doc_t','cyaml_doc_t').replace('turbo_yaml_node_t','cyaml_node_t').replace('turbo_yaml_root','cyaml_root')
s=s.replace('turbo_yaml_node_to_json','json_value_from_cyaml_node').replace('turbo_yaml_sequence_size','cyaml_seq_len').replace('turbo_yaml_sequence_get','cyaml_seq_get')
s=s.replace('cyaml_node_type(root) == TURBO_YAML_NODE_SEQUENCE','root != NULL && root->type == CYAML_SEQ').replace('turbo_yaml_node_type(root) == TURBO_YAML_NODE_SEQUENCE','root != NULL && root->type == CYAML_SEQ')
s=s.replace('turbo_yaml_from_json(json)','cyaml_doc_from_json_value(json)').replace('turbo_yaml_serialize(yaml, out_len)','cyaml_emit(yaml, NULL, out_len)')
s=re.sub(r'turbo_free_yaml\(&(\w+)\)',lambda m:f'(cyaml_free({m[1]}), {m[1]} = NULL)',s)
s=rep(s,'turbo_parse_yaml((const uint8_t *)yaml, len, &doc) != 0 || doc == NULL','(doc = cyaml_parse(yaml, len, NULL, NULL)) == NULL')
def yaml_selected(y):
 y=rep(y,'turbo_yaml_path_result_t *matches = NULL;',"cyaml_path_result_t matches = {0};\n  int has_path = yamlpath != NULL && yamlpath[0] != '\\0';")
 y=rep(y,"if (yamlpath != NULL && yamlpath[0] != '\\0') {",'if (has_path) {')
 a=y.index('    matches = turbo_yaml_path_query_ex(');b=y.index('    count = turbo_yaml_path_result_size(matches);',a)
 y=y[:a]+'''    qvm_limits_t native_limits = db_query_native_limits(query_limits);
    qvm_diagnostic_t native_diagnostic = {0};
    matches = cyaml_path_query_ex(doc, NULL, yamlpath, &native_limits, &native_diagnostic);
    db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);
    if (matches.error != NULL || native_diagnostic.status != QVM_STATUS_OK) {
      uint32_t error_pos = matches.error_pos;
      char path_message[DATA_BIND_QUERY_DIAGNOSTIC_MESSAGE_CAPACITY];
      snprintf(path_message, sizeof(path_message), "%s", matches.error ? matches.error :
               (native_diagnostic.message ? native_diagnostic.message : "query failed"));
      cyaml_path_result_free(&matches);
      cyaml_free(doc);
      db_error_format_path(error_path, sizeof(error_path), "yaml", yamlpath);
      return db_error_set(error, data_bind_query_failure_status(query_diagnostic), error_path, -1,
                          error_pos <= INT_MAX ? (int)error_pos : -1,
                          "YPATH parse failed: %s", path_message);
    }
'''+y[b:]
 y=y.replace('turbo_yaml_path_result_size(matches)','matches.count').replace('turbo_yaml_path_result_free(matches)','cyaml_path_result_free(&matches)')
 return y.replace('if (matches != NULL) node = turbo_yaml_path_result_get(matches, i);','if (has_path) node = matches.nodes[i];')
s=fn(s,'data_bind_parse_yaml_selected',yaml_selected)
# Query translation is confined to DataBind's versioned limit/diagnostic boundary.
def inject(f,lim='query_limits'):
 a=f.index('{')+1
 return f[:a]+f'\n  qvm_limits_t native_limits = db_query_native_limits({lim});\n  qvm_diagnostic_t native_diagnostic = {{0}};'+f[a:]
def csv_compile(f):
 f=inject(f,'parser->query_limits_configured ? &parser->query_limits : NULL')
 a=f.index('  compiled = ');b=f.index('  if (!compiled)',a)
 return f[:a]+'''  compiled = parser->csv_filter != NULL &&
             dsv_filter_compile_ex(parser->csv_filter, parser->path_or_expr,
                                   &native_limits, &native_diagnostic);
  db_query_diagnostic_copy(&parser->query_diagnostic, &native_diagnostic);
'''+f[b:]
s=fn(s,'data_bind_stream_csv_compile_filter',csv_compile)
s,n=re.subn(r'qvm_status_t query_status =\s*dsv_filter_query_diagnostic\(\s*([^,]+),\s*([^\)]+)\);',lambda m:f'''const qvm_diagnostic_t *native_diagnostic = dsv_filter_qvm_diagnostic({m[1]});
      qvm_status_t query_status = native_diagnostic ? native_diagnostic->status : QVM_STATUS_INVALID_ARGUMENT;
      db_query_diagnostic_copy({m[2]}, native_diagnostic);''',s);assert n==2,n
def stream_query(f):
 a=f.index('    json_path_program_t *verified =');b=f.index('    if (verified == NULL)',a)
 return f[:a]+'''    qvm_limits_t native_limits = db_query_native_limits(&parser->query_limits);
    qvm_diagnostic_t native_diagnostic = {0};
    json_path_program_t *verified = json_path_compile_ex(
        parser->path_or_expr, &native_limits, &native_diagnostic);
    db_query_diagnostic_copy(&parser->query_diagnostic, &native_diagnostic);
'''+f[b:]
s=fn(s,'data_bind_stream_set_query_limits',stream_query)
def json_query(f):
 f=inject(f)
 f=rep(f,'json_path_compile_ex(jsonpath, query_limits, query_diagnostic);','json_path_compile_ex(jsonpath, &native_limits, &native_diagnostic);\n  db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);')
 for mode in ['get','query']:
  old=f'json_path_{mode}_compiled_ex(root, program, query_diagnostic);'
  if old in f:f=rep(f,old,f'json_path_{mode}_compiled_ex(root, program, &native_diagnostic);\n    db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);')
 return f
s=fn(s,'data_bind_parse_json_path_with_query',json_query)
s=fn(s,'data_bind_parse_json_path_all_with_query',json_query)
def csv_query(f):
 f=inject(f)
 f,n=re.subn(r'\!\(query_limits \? dsv_filter_compile_ex\(filter, csvpath, query_limits,\s*query_diagnostic\)\s*:\s*dsv_filter_compile\(filter, csvpath\)\)','!dsv_filter_compile_ex(filter, csvpath, &native_limits, &native_diagnostic)',f);assert n==1,n
 a=f.index('  if (filter == NULL ||');b=f.index('{',a)
 f=f[:b+1]+'\n    db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);'+f[b+1:]
 a=f.index('  for (',b)
 return f[:a]+'  db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);\n'+f[a:]
s=fn(s,'data_bind_parse_csv_path_with_query',csv_query)
def xml_query(f):
 f=inject(f)
 a=f.index('      qvm_status_t query_status =');b=f.index('      if (query_status',a)
 f=f[:a]+'''      qvm_status_t query_status = salts_xml_document_xpath_query(
          &doc, xmlpath, &nodes, &native_limits, &native_diagnostic);
      db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);
'''+f[b:]
 return rep(f,'      if (query_status != QVM_STATUS_OK) {','      if (query_status != QVM_STATUS_OK) {\n        salts_xml_node_list_destroy(&nodes);')
s=fn(s,'data_bind_parse_xml_path_all_with_query',xml_query)
s=fn(s,'data_bind_validate_xml_path',lambda f:rep(f,'    turbo_xml_xpath_query(doc, xmlpath, &nodes);','''    if (salts_xml_document_xpath_query(&doc, xmlpath, &nodes, NULL, NULL) != QVM_STATUS_OK) {
      salts_xml_node_list_destroy(&nodes);
      salts_xml_document_destroy(&doc);
      return db_codec_error(codec, error, DATA_BIND_ERR_PARSE, "Invalid XMLPath expression");
    }'''))
# Build and serialize through native value handles; status zero means success.
s=s.replace('turbo_xml_node_t *node','salts_xml_node node').replace('turbo_xml_node_t *child','salts_xml_node child').replace('turbo_xml_set_text(node,','salts_xml_node_set_text(node,')
s=fn(s,'data_bind_value_to_xml',lambda f:f.replace('node == NULL','node.impl == NULL'))
s,n=re.subn(r'salts_xml_node child = turbo_xml_add_element\(node, ([^\)]+)\);',lambda m:f'''salts_xml_node child = {{0}};
          if (salts_xml_node_add_element(node, {m[1]}, &child) != SALTS_XML_OK) return 0;''',s);assert n==3,n
s=rep(s,'      child = turbo_xml_add_element(node, key);','      if (salts_xml_node_add_element(node, key, &child) != SALTS_XML_OK) return 0;')
s=fn(s,'data_bind_value_to_xml',lambda f:f.replace('child == NULL','child.impl == NULL').replace('!child','!child.impl'))
s=rep(s,'  turbo_xml_doc_t *xml;\n  turbo_xml_node_t *root;','  salts_xml_document xml = {0};\n  salts_xml_node root = {0};')
s=rep(s,'''  xml = turbo_xml_create_document(object->type_name);
  root = turbo_xml_root_element(xml);
  if (!xml || !root || !data_bind_value_to_xml(object->value, root, 0)) {''','''  if (salts_xml_document_create(&xml, object->type_name) != SALTS_XML_OK) {
    return db_error_set(error, DATA_BIND_ERR_OOM, "xml", -1, -1,
                        "Unable to create XML document");
  }
  root = salts_xml_document_root(&xml);
  if (!root.impl || !data_bind_value_to_xml(object->value, root, 0)) {''')
s=s.replace('turbo_free_xml(&xml)','salts_xml_document_destroy(&xml)').replace('turbo_xml_serialize(xml, out_len)','salts_xml_document_serialize(&xml, out_len)')
put(p,s)
p='tbe/data_bind/tbe_typed.c';s=names(orig(p)).replace('#include "turbo_parser.h"','#include <json_parser.h>')
s=re.sub(r'turbo_free_json\(&([\w>\-]+)\)',lambda m:f'(json_free({m[1]}), {m[1]} = NULL)',s)
put(p,s)
p='tbe/data_bind/tbe_typed.c';s=(R/p).read_text();s=rep(s,'void tbe_typed_json_free(json_value_t **value) { turbo_free_json(value); }','''void tbe_typed_json_free(json_value_t **value) {
  if (!value) return;
  json_free(*value);
  *value = NULL;
}''');put(p,s)
p='tbe/data_bind/CMakeLists.txt';s=orig(p);a=s.index('set(DATA_BIND_PARSER_COMPAT_TARGET');b=s.index('add_library(\n  ${DATA_BIND_TARGET}',a);s=s[:a]+s[b:]
s=s.replace('    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/parser_compat/include>\n','')
s=rep(s,'    ${DATA_BIND_PARSER_COMPAT_TARGET}\n','''    Salts::JsonParser
    Salts::CsvParser
    Salts::XmlParser
    Salts::CYaml
    Salts::CYamlJsonAdapter
''')
s=rep(s,'    Salts::CSTL)','''    Salts::CSTL
    Salts::DateTimeParser
    Salts::QueryVM)''')
s=s.replace('    parser_compat/include/turbo_parser_common.h\n','').replace('    parser_compat/include/turbo_parser_datetime.h\n','');put(p,s)
# All legacy files are tracked; remove exactly this facade, never unrelated paths.
for p in subprocess.check_output(['git','ls-files','tbe/data_bind/parser_compat'],cwd=R,text=True).splitlines():
 (R/p).unlink(missing_ok=True)
for p in sorted((R/'tbe/data_bind/parser_compat').rglob('*'),key=lambda p:len(p.parts),reverse=True):
 if p.is_dir():p.rmdir()
(R/'tbe/data_bind/parser_compat').rmdir()

p=R/'tbe/data_bind/data_bind.c'
s=p.read_text().replace('cyaml_node_to_json(doc, node)', 'json_value_from_cyaml_node(doc, node)')
s=s.replace('if (!value || !node || depth', 'if (!value || !node.impl || depth')
s=fn(s,'data_bind_parse_xml_path_all_with_query', lambda f:f.replace('int index = 0;', 'size_t index = 0;'))
s=fn(s,'data_bind_validate_xml_path', lambda f:f.replace('int index;', 'size_t index;'))
s=s.replace('"%s[%d]", xmlpath, index + 1', '"%s[%zu]", xmlpath, index + 1')
p.write_text(s)
from pathlib import Path
import re
R=Path.cwd();p=R/'tbe/data_bind/data_bind.c';s=p.read_text()
s=s.replace('  qvm_limits_t native_limits = db_query_native_limits(parser->query_limits_configured ? &parser->query_limits : NULL);', '  qvm_limits_t native_limits;')
s=s.replace('  header_doc_len = parser->csv_header_len + 1;', '  native_limits = db_query_native_limits(\n      parser->query_limits_configured ? &parser->query_limits : NULL);\n  header_doc_len = parser->csv_header_len + 1;')
# Remove redundant old out-parameter checks, now subsumed by pointer-return parse.
s=re.sub(r'(\((\w+) = json_parse\([^;\n]+?\)\) == NULL) \|\| \2 == NULL',r'\1',s)
s=re.sub(r'(\((\w+) = csv_parse_opts\([^;\n]+?\)\) == NULL) \|\|\s*\2 == NULL',r'\1',s)
s=s.replace('  selected = json_path_get_compiled_ex(root, program, &native_diagnostic);\n    db_query','  selected = json_path_get_compiled_ex(root, program, &native_diagnostic);\n  db_query')
s=s.replace('    db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);\n  for (raw_row', '    db_query_diagnostic_copy(query_diagnostic, &native_diagnostic);\n    for (raw_row')
s=s.replace('''        const qvm_diagnostic_t *native_diagnostic = dsv_filter_qvm_diagnostic(filter);
      qvm_status_t query_status = native_diagnostic ? native_diagnostic->status : QVM_STATUS_INVALID_ARGUMENT;
      db_query_diagnostic_copy(query_diagnostic, native_diagnostic);''', '''        const qvm_diagnostic_t *filter_diagnostic = dsv_filter_qvm_diagnostic(filter);
        qvm_status_t query_status = filter_diagnostic ? filter_diagnostic->status
                                                    : QVM_STATUS_INVALID_ARGUMENT;
        db_query_diagnostic_copy(query_diagnostic, filter_diagnostic);''')
s=s.replace('      qvm_status_t query_status = native_diagnostic ? native_diagnostic->status : QVM_STATUS_INVALID_ARGUMENT;', '      qvm_status_t query_status = native_diagnostic ? native_diagnostic->status\n                                                   : QVM_STATUS_INVALID_ARGUMENT;')
p.write_text(s)
p=R/'tbe/data_bind/README.md';s=p.read_text().replace('并通过内部 compatibility 层消费基础 Salts 的具体格式解析能力。','并直接消费基础 Salts 的具体格式解析器，不再构建或安装 parser compatibility 层。')
a=s.index('DataBind 2.5 只定义两条强类型路线：')
s=s[:a]+'''### 原生 parser 依赖与迁移

格式解析直接链接 `Salts::JsonParser`、`Salts::CsvParser`、`Salts::XmlParser`、
`Salts::CYaml` 和 `Salts::CYamlJsonAdapter`。公开 datetime 和查询预算/诊断分别依赖
`Salts::DateTimeParser`、`Salts::QueryVM`，由 `Salts::DataBind` 的公开链接接口传递。

`parser_compat/` 及其构建目标、头文件安装项已移除；不存在另一份 facade 或 fallback。
调用方应包含 `data_bind.h`，datetime 使用原生 `datetime_t`（也可用 `DataBindDateTime`），
查询状态使用 `QVM_STATUS_*`。不得继续包含 `turbo_parser*.h` 或使用 `turbo_*` parser 类型。
`DataBindQueryLimits` 保留带 `size` 的版本化配置；`DataBindQueryDiagnostic` 保留错误消息的
自有副本，不能直接用含借用消息指针的 `qvm_diagnostic_t` 替代它。

JSON/CSV 文档、YAML 文档与选择结果、XML 文档与节点列表均由各自 Salts parser 创建和释放。
DataBind 只保留转换后的领域值；流式 XML 的增量词法解析属于 `Salts::XmlParser`，
不再由 DataBind 自行实现。流式回调、取消、预算和错误后的资源清理仍由现有回归测试约束。
既有 `turbo_parser.data_bind.*.v1` CMeta 语义标识不是 parser API，保持不变以避免破坏类型身份。

'''+s[a:];p.write_text(s)

p=R/'tests/databind_direct_parsers/installed/CMakeLists.txt'
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text('cmake_minimum_required(VERSION 3.20)\nproject(DataBindNativeInstalled C)\nfind_package(SaltsUtils CONFIG REQUIRED)\nget_target_property(imported Salts::DataBind IMPORTED)\nif(NOT imported)\n  message(FATAL_ERROR "Test requires the installed DataBind target")\nendif()\nadd_executable(databind_native_consumer consumer.c)\ntarget_compile_features(databind_native_consumer PRIVATE c_std_11)\ntarget_link_libraries(databind_native_consumer PRIVATE Salts::DataBind)\nif(CMAKE_C_COMPILER_ID MATCHES "GNU|Clang" AND NOT WIN32)\n  target_compile_options(databind_native_consumer PRIVATE -fsanitize=address,undefined)\n  target_link_options(databind_native_consumer PRIVATE -fsanitize=address,undefined)\nendif()\nenable_testing()\nadd_test(NAME databind_native_installed COMMAND databind_native_consumer)\n')

p=R/'tests/databind_direct_parsers/installed/consumer.c'
p.parent.mkdir(parents=True,exist_ok=True)
p.write_text('#include <data_bind.h>\n#include <tbe_typed.h>\n#include <datetime_parser.h>\n#include <query_vm.h>\n#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n  const char path[] = "databind-native-consumer.tbe";\n  const char schema[] = "message Event { datetime at; uint32 id; string name; }\\n";\n  const char json[] = "{\\"name\\":\\"native\\",\\"id\\":7,\\"at\\":\\"Sat, 04 Mar 2006 13:27:54 GMT\\"}";\n  DataBindQueryLimits limits = DATA_BIND_QUERY_LIMITS_INIT;\n  DataBindQueryDiagnostic diagnostic = DATA_BIND_QUERY_DIAGNOSTIC_INIT;\n  DataBindError error = DATA_BIND_ERROR_INIT;\n  DataBind *bind = NULL;\n  DataBindValue *value = NULL;\n  datetime_t date;\n  FILE *file = fopen(path, "wb");\n  int failed = 1;\n  if (!file) return 1;\n  size_t written = fwrite(schema, 1, sizeof(schema) - 1, file);\n  int close_result = fclose(file);\n  if (written != sizeof(schema) - 1 || close_result != 0) goto cleanup;\n  if (limits.max_steps != QVM_DEFAULT_MAX_STEPS || diagnostic.status != QVM_STATUS_OK)\n    goto cleanup;\n  if (data_bind_create(path, &bind, &error) != DATA_BIND_OK) goto cleanup;\n  if (data_bind_parse_json(bind, "Event", json, sizeof(json) - 1, &value, &error) != DATA_BIND_OK)\n    goto cleanup;\n  if (!data_bind_value_as_datetime(data_bind_value_get(value, "at"), &date) || date.year != 2006)\n    goto cleanup;\n  if (data_bind_value_as_int(data_bind_value_get(value, "id")) != 7) goto cleanup;\n  const char *name = data_bind_value_as_string(data_bind_value_get(value, "name"));\n  if (!name || strcmp(name, "native") != 0) goto cleanup;\n  failed = 0;\ncleanup:\n  if (failed) fprintf(stderr, "Installed native DataBind consumer failed: %s\\n", error.message);\n  data_bind_value_free(value);\n  data_bind_free(bind);\n  remove(path);\n  return failed;\n}\n')
